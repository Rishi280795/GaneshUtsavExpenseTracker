# Ganesh Utsav Mandal Expense & Donation Tracker

Android app built with Kotlin + Jetpack Compose. This package is prepared for AndroidIDE on Android phones.

## Features
- Dashboard: donations, expenses, balance and budget usage
- Add expenses with category, payer, payment mode and notes
- Add donations with donor and payment mode
- Category-wise expense report
- Marathi / English toggle
- Offline local storage using SharedPreferences/JSON
- Android 8.0+ (API 26)

## AndroidIDE
1. Extract this ZIP.
2. Open the folder containing `settings.gradle.kts` in AndroidIDE.
3. If AndroidIDE asks to install Gradle/build tools, allow it.
4. Build the project with **Assemble Debug**.
5. Install `app/build/outputs/apk/debug/app-debug.apk`.

The included `gradlew` is a launcher script that uses the Gradle executable supplied by AndroidIDE. The original package failed because `gradlew` was missing.
