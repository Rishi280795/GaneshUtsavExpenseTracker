package com.example.ganeshutsav.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "donations")
data class Donation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val donor: String,
    val amount: Double,
    val mode: String = "Cash",
    val date: Long = System.currentTimeMillis(),
    val note: String = ""
)
