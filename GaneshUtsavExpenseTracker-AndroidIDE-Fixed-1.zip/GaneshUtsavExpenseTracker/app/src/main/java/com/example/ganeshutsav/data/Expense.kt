package com.example.ganeshutsav.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val amount: Double,
    val paidBy: String,
    val date: Long = System.currentTimeMillis(),
    val note: String = ""
)
