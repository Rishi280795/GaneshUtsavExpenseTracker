package com.example.ganeshutsav.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budget WHERE id = 1") fun observe(): Flow<Budget?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(item: Budget)
}
