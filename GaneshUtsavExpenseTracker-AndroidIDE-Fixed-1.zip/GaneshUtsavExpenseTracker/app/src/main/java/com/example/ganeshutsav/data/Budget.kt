package com.example.ganeshutsav.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budget")
data class Budget(
    @PrimaryKey val id: Int = 1,
    val amount: Double = 0.0
)
