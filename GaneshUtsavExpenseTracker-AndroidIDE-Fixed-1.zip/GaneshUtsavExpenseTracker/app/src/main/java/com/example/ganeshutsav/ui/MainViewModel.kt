package com.example.ganeshutsav.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ganeshutsav.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    val expenses = db.expenseDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalExpenses = db.expenseDao().observeTotal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    val donations = db.donationDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalDonations = db.donationDao().observeTotal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    val budget = db.budgetDao().observe().map { it?.amount ?: 0.0 }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addExpense(title: String, category: String, amount: Double, paidBy: String, note: String) = viewModelScope.launch { db.expenseDao().insert(Expense(title=title, category=category, amount=amount, paidBy=paidBy, note=note)) }
    fun deleteExpense(item: Expense) = viewModelScope.launch { db.expenseDao().delete(item) }
    fun addDonation(donor: String, amount: Double, mode: String, note: String) = viewModelScope.launch { db.donationDao().insert(Donation(donor=donor, amount=amount, mode=mode, note=note)) }
    fun deleteDonation(item: Donation) = viewModelScope.launch { db.donationDao().delete(item) }
    fun saveBudget(amount: Double) = viewModelScope.launch { db.budgetDao().save(Budget(amount=amount)) }
}
