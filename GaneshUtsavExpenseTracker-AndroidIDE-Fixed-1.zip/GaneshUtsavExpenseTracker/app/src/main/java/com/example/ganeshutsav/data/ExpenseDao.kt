package com.example.ganeshutsav.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY date DESC, id DESC") fun observeAll(): Flow<List<Expense>>
    @Insert suspend fun insert(expense: Expense)
    @Delete suspend fun delete(expense: Expense)
    @Query("SELECT COALESCE(SUM(amount),0) FROM expenses") fun observeTotal(): Flow<Double>
}
