package com.example.ganeshutsav.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DonationDao {
    @Query("SELECT * FROM donations ORDER BY date DESC, id DESC") fun observeAll(): Flow<List<Donation>>
    @Query("SELECT COALESCE(SUM(amount),0) FROM donations") fun observeTotal(): Flow<Double>
    @Insert suspend fun insert(item: Donation)
    @Delete suspend fun delete(item: Donation)
}
