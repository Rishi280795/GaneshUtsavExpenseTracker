package com.example.ganeshutsav

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Entry(val id: Long, val type: String, val amount: Double, val category: String, val person: String, val mode: String, val note: String, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GaneshApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GaneshApp() {
    val context = LocalContext.current
    var entries by remember { mutableStateOf(loadEntries(context)) }
    var budget by remember { mutableStateOf(loadBudget(context)) }
    var tab by remember { mutableStateOf(0) }
    var marathi by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var addType by remember { mutableStateOf("Expense") }

    fun save() { saveEntries(context, entries) }
    val donations = entries.filter { it.type == "Donation" }.sumOf { it.amount }
    val expenses = entries.filter { it.type == "Expense" }.sumOf { it.amount }
    val balance = donations - expenses

    MaterialTheme {
        Scaffold(
            topBar = {
                SmallTopAppBar(
                    title = { Text(if (marathi) "गणेश उत्सव मंडळ" else "Ganesh Utsav Mandal") },
                    colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = MaterialTheme.colorScheme.onPrimary),
                    actions = { TextButton(onClick = { marathi = !marathi }) { Text(if (marathi) "EN" else "मराठी", color = MaterialTheme.colorScheme.onPrimary) } }
                )
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                when (tab) {
                    0 -> Dashboard(donations, expenses, balance, budget, entries, marathi) { tab = 1 }
                    1 -> EntryList(entries, false, marathi) { addType = "Expense"; showAdd = true }
                    2 -> EntryList(entries, true, marathi) { addType = "Donation"; showAdd = true }
                    3 -> Reports(entries, budget, marathi)
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf(if (marathi) "मुख्य" else "Home", if (marathi) "खर्च" else "Expenses", if (marathi) "देणगी" else "Donations", if (marathi) "अहवाल" else "Reports").forEachIndexed { i, label ->
                        FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) })
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddEntryDialog(type = addType, marathi = marathi, onDismiss = { showAdd = false }, onSave = { amount, category, person, mode, note ->
            entries = entries + Entry(System.currentTimeMillis(), addType, amount, category, person, mode, note, now())
            save(); showAdd = false
            Toast.makeText(context, if (marathi) "नोंद जतन झाली" else "Saved", Toast.LENGTH_SHORT).show()
        })
    }
}

@Composable
private fun Dashboard(donations: Double, expenses: Double, balance: Double, budget: Double, entries: List<Entry>, marathi: Boolean, onExpense: () -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(if (marathi) "उत्सव आर्थिक डॅशबोर्ड" else "Festival Finance Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { SummaryCard(if (marathi) "एकूण देणगी" else "Total Donations", donations) }
        item { SummaryCard(if (marathi) "एकूण खर्च" else "Total Expenses", expenses) }
        item { SummaryCard(if (marathi) "शिल्लक" else "Balance", balance) }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                Text(if (marathi) "बजेट" else "Festival Budget", fontWeight = FontWeight.Bold)
                Text("₹ %.2f / ₹ %.2f".format(expenses, budget))
                val p = if (budget > 0) (expenses / budget).coerceIn(0.0, 1.0) else 0.0
                androidx.compose.material3.LinearProgressIndicator(progress = { p }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text("%.0f%%".format(p * 100))
            } }
        }
        item { Button(onClick = onExpense, Modifier.fillMaxWidth()) { Text(if (marathi) "नवीन खर्च नोंदवा" else "Add Expense") } }
        item { Text(if (marathi) "अलीकडील नोंदी" else "Recent Entries", fontWeight = FontWeight.Bold) }
        items(entries.takeLast(5).reversed()) { e -> EntryRow(e) }
    }
}

@Composable private fun SummaryCard(title: String, amount: Double) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(title); Text("₹ %.2f".format(amount), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) } } }

@Composable
private fun EntryList(entries: List<Entry>, donations: Boolean, marathi: Boolean, add: () -> Unit) {
    val type = if (donations) "Donation" else "Expense"
    val list = entries.filter { it.type == type }.reversed()
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (donations) (if (marathi) "देणगी" else "Donations") else (if (marathi) "खर्च" else "Expenses"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f)); Button(onClick = add) { Text("+") }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(list) { EntryRow(it) } }
    }
}

@Composable private fun EntryRow(e: Entry) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Row(Modifier.fillMaxWidth()) { Text(e.category, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("₹ %.2f".format(e.amount), fontWeight = FontWeight.Bold) }; Text("${e.person} • ${e.mode} • ${e.date}"); if (e.note.isNotBlank()) Text(e.note) } } }

@Composable
private fun Reports(entries: List<Entry>, budget: Double, marathi: Boolean) {
    val expenses = entries.filter { it.type == "Expense" }
    val grouped = expenses.groupBy { it.category }.mapValues { it.value.sumOf { x -> x.amount } }.toList().sortedByDescending { it.second }
    val total = expenses.sumOf { it.amount }
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Text(if (marathi) "खर्च अहवाल" else "Expense Report", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp)); Text("Total: ₹ %.2f".format(total)); Text("Budget: ₹ %.2f".format(budget)); HorizontalDivider(Modifier.padding(vertical = 10.dp))
        if (grouped.isEmpty()) Text(if (marathi) "अजून खर्च नोंदवलेला नाही." else "No expenses recorded yet.")
        grouped.forEach { (cat, amount) -> Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) { Text(cat); Spacer(Modifier.weight(1f)); Text("₹ %.2f".format(amount)) } }
    }
}

@Composable
private fun AddEntryDialog(type: String, marathi: Boolean, onDismiss: () -> Unit, onSave: (Double, String, String, String, String) -> Unit) {
    var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf(if (type == "Donation") "Donation" else "Decoration") }; var person by remember { mutableStateOf("") }; var mode by remember { mutableStateOf(if (type == "Donation") "UPI" else "Cash") }; var note by remember { mutableStateOf("") }
    val categories = if (type == "Donation") listOf("Donation") else listOf("Decoration","Sound","Food","Prasad","Electricity","Mandap","Cultural Program","Transport","Other")
    var menu by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (type == "Donation") if (marathi) "देणगी जोडा" else "Add Donation" else if (marathi) "खर्च जोडा" else "Add Expense") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount ₹") }, singleLine = true)
            BoxLikeDropdown(category, categories, menu, { menu = true }, { category = it; menu = false })
            OutlinedTextField(person, { person = it }, label = { Text(if (type == "Donation") "Donor" else "Paid by") }, singleLine = true)
            OutlinedTextField(mode, { mode = it }, label = { Text(if (type == "Donation") "Mode (Cash/UPI/Bank/Cheque)" else "Payment mode") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("Note") })
        }
    }, confirmButton = { Button(onClick = { val a = amount.toDoubleOrNull(); if (a != null && a > 0) onSave(a, category, person, mode, note) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable private fun BoxLikeDropdown(value: String, options: List<String>, expanded: Boolean, open: () -> Unit, select: (String) -> Unit) { Column { OutlinedButton(onClick = open, Modifier.fillMaxWidth()) { Text(value); Spacer(Modifier.weight(1f)); Text("▼") }; DropdownMenu(expanded, { select(value) }) { options.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { select(it) }) } } } }

private fun now(): String = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date())
private const val PREF = "ganesh_tracker"
private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
private fun loadBudget(c: Context) = prefs(c).getFloat("budget", 150000f).toDouble()
private fun loadEntries(c: Context): List<Entry> { return try { val a = JSONArray(prefs(c).getString("entries", "[]")); buildList { for (i in 0 until a.length()) { val o = a.getJSONObject(i); add(Entry(o.getLong("id"),o.getString("type"),o.getDouble("amount"),o.getString("category"),o.getString("person"),o.getString("mode"),o.getString("note"),o.getString("date"))) } } } catch (_: Exception) { emptyList() } }
private fun saveEntries(c: Context, entries: List<Entry>) { val a = JSONArray(); entries.forEach { e -> a.put(JSONObject().apply { put("id",e.id);put("type",e.type);put("amount",e.amount);put("category",e.category);put("person",e.person);put("mode",e.mode);put("note",e.note);put("date",e.date) }) }; prefs(c).edit().putString("entries",a.toString()).apply() }
