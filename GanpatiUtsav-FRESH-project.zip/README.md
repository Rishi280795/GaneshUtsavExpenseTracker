# Ganpati Utsav Accounts

Android app for Ganpati Utsav contribution (vargani), unpaid amounts, expenses and CSV report export.

## GitHub Actions build
1. Upload the contents of this project to the repository root.
2. Keep `app/`, `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, and `.github/workflows/build-apk.yml` at the repository root.
3. Open **Actions** -> **Build Android APK**.
4. Select **Run workflow** on `main`.
5. Open the successful run.
6. Scroll to **Artifacts** and download `GanpatiUtsavAccounts-debug`.
7. Extract the downloaded artifact and install `app-debug.apk` on the Android phone.

Do not upload this ZIP inside another `source/` directory. The workflow builds the `app` folder directly.
